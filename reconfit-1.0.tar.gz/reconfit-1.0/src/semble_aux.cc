// semble_aux.cc -
//
// Saturday, October 22 2011
//

#include"semble_aux.h"

using namespace ENSEM;

namespace SEMBLE
{
  //sample an ensemble scalar to find the range

  std::pair<double, double> findRange(const EnsemReal &eObj, const int freq/* = 10*/)
  {
    if(freq <= 0)
      {
	std::cout << __PRETTY_FUNCTION__ << __FILE__ << __LINE__ << " " << freq << " is an invalid sampling parameter, exiting" << std::endl;
	exit(1);
      }

    int sz = eObj.size();

    if(sz < 2)
      {
        std::cout << __PRETTY_FUNCTION__ << __FILE__ << __LINE__ << " ensem object too small to histo" << std::endl;
        exit(1);
      }

    double min, max;
    min = toScalar(eObj.elem(0));
    max = toScalar(eObj.elem(1));

    if(min > max)
      {
        double swap = min;
        min = max;
        max = swap;
      }

    for(int sample = 2; sample < sz; sample += freq)
      {
        double samp = toScalar(eObj.elem(sample));
        min = (min < samp) ? min : samp;
        max = (max > samp) ? max : samp;
      }

    return std::pair<double, double>(min, max);
  }

  //assumes we are not getting a jackkniffed ensemble, can scale up
  std::vector<std::pair<double, int> > genHistogram(const EnsemReal &e,
						    const int nbins,
						    const int freq /* = 10*/,
						    const bool scaleUp /*= false*/)
  {
    EnsemReal eObj(e);

    if(scaleUp)
      eObj = rescaleEnsemUp(e);

    std::pair<double, double> range = findRange(eObj, freq);

    Histogram histo(range.first, range.second, nbins);

    int sz = eObj.size();

    for(int i = 0; i < sz; ++i)
      histo.Add(toScalar(eObj.elem(i)));

    return  histo.genHisto();
  }

  //something to write the histogram to a given path
  void makeEnsemHistogram(const EnsemReal &e,
                          const std::vector<std::string> &file_path,
                          const int nbins,
                          const int freq /* = 10*/,
                          const bool scaleUp /* = false*/)
  {
    std::vector<std::pair<double, int> > histo;
    std::vector<std::string> path(file_path);
    std::string fname;
    std::string work_path;
    std::vector<std::string>::const_iterator it;
    std::vector<std::pair<double, int> >::const_iterator vit;
    std::ofstream out;


    histo = genHistogram(e, nbins, freq, scaleUp);
    fname = path.back();
    path.pop_back();
    work_path = path[0];
    path.erase(path.begin());

    SEMBLEIO::makeDirectoryPath(work_path);

    for(it = path.begin(); it != path.end(); ++it)
      {
        work_path += std::string("/");
        work_path += *it;
        SEMBLEIO::makeDirectoryPath(work_path);
      }

    work_path += std::string("/");
    fname = work_path + fname;

    out.open(fname.c_str());

    for(vit = histo.begin(); vit != histo.end(); ++vit)
      out << (*vit).first << " " << (*vit).second << "\n";

    out.close();
  }

  //one more layer to be able to write histograms for a SembleVector
  void makeHistogram(const SembleVector<double> &sv,
                     const std::vector<std::vector<std::string> > &file_path,
                     const int nbins,
                     const int freq /* = 10*/,
                     const bool scaleUp /* = false*/)
  {
    if(sv.getN() != file_path.size())
      {
        std::cout << __PRETTY_FUNCTION__ << __FILE__ << __LINE__ << " mismatch error, exiting" << std::endl;
        exit(1);
      }

    int sz = sv.getN();

    for(int elem = 0; elem < sz; ++elem)
      makeEnsemHistogram(sv.getEnsemElement(elem), file_path[elem], nbins, freq, scaleUp);
  }
}
