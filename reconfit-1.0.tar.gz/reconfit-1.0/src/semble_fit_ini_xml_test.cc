// semble_fit_ini_xml_test.cc -
//
// Friday, October  7 2011
//

#include"semble_fit_ini_xml.h"

using namespace std;
using namespace ENSEM;
using namespace SEMBLE;

int main(int argc, char *argv[])
{
  if(argc != 2)
    {
      cerr << "usage: " << argv[0] << ": <xmlinifile> " << endl;
      exit(1);
    }

  string xmlinifile;
  istringstream val(argv[1]);
  val >> xmlinifile;
  cout << "Loading xmlinifile: " << xmlinifile << endl;

  // Read parameters from xml ini file
  FitIniProps_t inikeys;

  try
    {
      XMLReader xml_in(xmlinifile);
      read(xml_in, "/FitIniParams", inikeys);
    }
  catch(const std::string &e)
    {
      cerr << __func__ << ": ERROR: can't read xmlinifile (" << xmlinifile << "): " << e << endl;
    }

  std::cout << inikeys << std::endl;
  return 0;
}
